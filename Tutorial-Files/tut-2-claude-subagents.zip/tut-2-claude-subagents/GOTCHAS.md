# GOTCHAS.md

## Operator Precedence is Encoded in Parsing Order

Precedence is determined by which `parse*()` function handles the operator, **not** by the tree structure.

**Parsing levels (top to bottom):**
1. `parseExpression()` → + and - (lowest precedence, at root)
2. `parseTerm()` → * and / (medium precedence)
3. `parseFactor()` → ^, numbers, parentheses (highest precedence)

**Example:** `2 + 3 * 4` becomes:
```
      +          ← parseExpression handles +
     / \
    2   *        ← parseTerm handles *
       / \
      3   4
```
Result: `2 + (3 * 4) = 14` ✓

**Changing precedence:** Move operator to a different function level.
- To make ^ have lower precedence than *: move it from `parseFactor()` to `parseTerm()`
- To make + have higher precedence than *: move it from `parseExpression()` to `parseTerm()`

## Power is Right-Associative

`2 ^ 3 ^ 2` evaluates as `2 ^ (3 ^ 2) = 2 ^ 9 = 512`, **not** `(2 ^ 3) ^ 2 = 64`.

**Why:** In `parseFactor()`, power calls itself recursively on the right child:
```cpp
ASTNode* Parser::parseFactor() {
    if (peek().type == Token::POW) {
        consume();
        ASTNode* right = parseFactor();  // ← Recursive call creates right-associativity
        ...
    }
}
```

If you want left-associativity (like most operators), use a loop instead:
```cpp
while (peek().type == Token::POW) {
    consume();
    ASTNode* right = /* parse next factor */;
    left = /* create node with left, '^', right */;
}
```

## Division by Zero is Caught at Evaluation Time

The parser allows `5 / 0` syntactically. Error only occurs when `Calculator::evaluate()` tries to compute it:

```cpp
ASTNode* ast = parser.parse("5 / 0");  // ✓ No error yet
double result = calc.evaluate(ast);    // ✗ Throws std::invalid_argument
```

**Why:** Validation is deferred to allow for symbolic manipulation or lazy evaluation in the future.

**To catch at parse time:** Add a validation pass after parsing but before evaluation.

## Memory Leaks from Incomplete Parsing

If parsing throws an exception, the partially-built AST is **not** cleaned up:

```cpp
try {
    ASTNode* ast = parser.parse("5 +");  // Throws halfway through
    // AST is partially allocated but never deleted
} catch (const std::exception& e) {
    std::cout << "Error: " << e.what() << std::endl;
    // Leak: left operand of + is allocated but unreachable
}
```

**Solution for production:** Use `std::unique_ptr<ASTNode>` for automatic cleanup.

**For now:** Not a concern in the learning project, but something to be aware of.

## Parentheses are Handled in `parseFactor()`

There's no separate `parseParentheses()` function. Instead:

```cpp
if (peek().type == Token::LPAREN) {
    consume();              // Skip '('
    ASTNode* expr = parseExpression();  // Parse contents
    if (peek().type != Token::RPAREN) {
        throw std::invalid_argument("Expected ')'");
    }
    consume();              // Skip ')'
    return expr;
}
```

This means parentheses work at the highest precedence level only. Expressions like `2 + (3 * 4)` work, but `(2 + 3) * (4 - 1)` also works because each `(...)` is a complete expression.

## Common Tasks

### Add a New Operator (e.g., Modulo `%`)

1. **Add token type** in `src/parser.h`:
   ```cpp
   struct Token {
       enum Type { NUMBER, PLUS, MINUS, MULT, DIV, POW, MOD, LPAREN, RPAREN, END };
       ...
   };
   ```

2. **Tokenize** in `Parser::tokenize()`:
   ```cpp
   else if (expression[i] == '%') {
       result.push_back(Token(Token::MOD));
       i++;
   }
   ```

3. **Parse** — add to the appropriate level. Modulo has same precedence as * and /:
   ```cpp
   ASTNode* Parser::parseTerm() {
       ...
       while (peek().type == Token::MULT || peek().type == Token::DIV || peek().type == Token::MOD) {
           Token op = consume();
           ASTNode* right = parseFactor();
           
           ASTNode* node = new ASTNode();
           node->op = (op.type == Token::MULT) ? '*' : (op.type == Token::DIV) ? '/' : '%';
           ...
       }
   }
   ```

4. **Evaluate** in `Calculator::applyOp()`:
   ```cpp
   case '%':
       if (right == 0) throw std::invalid_argument("Modulo by zero");
       return static_cast<int>(left) % static_cast<int>(right);
   ```

5. **Test** in `tests/parser_test.cpp` and `tests/calculator_test.cpp`:
   ```cpp
   TEST_F(ParserTest, Modulo) {
       double result = parseAndEval("10 % 3");
       EXPECT_EQ(result, 1);
   }
   ```

### Debug an AST

Add a helper function to print the tree structure. In `src/cli.cpp` or a debug header:

```cpp
void printAST(calc::ASTNode* node, int depth = 0) {
    if (!node) return;
    std::cout << std::string(depth * 2, ' ');
    if (node->op == '\0') {
        std::cout << "Num: " << node->value << std::endl;
    } else {
        std::cout << "Op: " << node->op << std::endl;
    }
    printAST(node->left, depth + 1);
    printAST(node->right, depth + 1);
}
```

Call it before evaluation:
```cpp
ASTNode* ast = parser.parse("2 + 3 * 4");
printAST(ast);
double result = calc.evaluate(ast);
```

Output:
```
Op: +
  Num: 2
  Op: *
    Num: 3
    Num: 4
```

### Handle Negative Numbers

Currently, `-5` is parsed as `0 - 5`. To allow true negative literals, modify `Parser::parseFactor()`:

```cpp
ASTNode* Parser::parseFactor() {
    // Handle unary minus
    if (peek().type == Token::MINUS) {
        consume();
        ASTNode* operand = parseFactor();
        ASTNode* node = new ASTNode();
        node->op = '-';
        node->left = new ASTNode();
        node->left->value = 0;
        node->right = operand;
        return node;
    }
    
    // Rest of the function...
}
```

This converts `-5` to `(0 - 5)`, which is correct semantically and already handled by the evaluator.
