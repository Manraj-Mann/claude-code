# ARCHITECTURE.md

## Data Flow

```
User input (string)
  ↓
CLI::run() reads line
  ↓
Parser::parse() tokenizes & builds AST
  ↓
Calculator::evaluate() recursively computes result
  ↓
Display result to user
```

## Module Structure

### Parser (`src/parser.h`, `src/parser.cpp`)

Converts a string like `"2 + 3 * 4"` into an Abstract Syntax Tree (AST).

**Token types:** NUMBER, PLUS, MINUS, MULT, DIV, POW, LPAREN, RPAREN, END

**Parsing strategy:** Recursive descent with three precedence levels:
- `parseExpression()` — handles + and - (lowest precedence, at root of tree)
- `parseTerm()` — handles * and / (medium precedence)
- `parseFactor()` — handles ^, numbers, and parentheses (highest precedence)

**Output:** Heap-allocated `ASTNode*` tree

### Calculator (`src/calculator.h`, `src/calculator.cpp`)

Evaluates an AST recursively.

- **Leaf nodes** (op == '\0'): return the number value
- **Internal nodes**: recursively evaluate left & right subtrees, apply operator

**Operators:** +, -, *, /, ^ (power)

**Error handling:** Throws `std::invalid_argument` on division by zero or unknown operator

### CLI (`src/cli.h`, `src/cli.cpp`)

REPL (Read-Eval-Print Loop) for user interaction.

1. Prints welcome message
2. Reads user input
3. Parses and evaluates
4. Prints result or error message
5. Repeats until user types "exit"

**Error handling:** Catches `std::exception`, displays error, continues loop

## Key Design Decisions

**Why separate Parser and Calculator?**
- Parser builds the AST, which is a separate concern from evaluation
- Allows for future features like symbolic manipulation, optimization, or printing the AST
- Testable independently

**Why recursive descent parsing?**
- Easy to understand and implement
- Operator precedence is naturally encoded in the recursion depth
- No need for a separate precedence table

**Why AST instead of direct evaluation?**
- More flexible — can inspect, transform, or reuse the AST
- Clearer separation of concerns

**Why heap-allocated AST?**
- Recursive tree structure requires dynamic allocation
- Each node can have independent left/right children

## Deployment

To use this library in another project:

```cpp
#include "parser.h"
#include "calculator.h"

int main() {
    calc::Parser parser;
    calc::Calculator calculator;
    
    std::string expr = "2 + 3 * 4";
    calc::ASTNode* ast = parser.parse(expr);
    double result = calculator.evaluate(ast);  // 14.0
    calculator.deleteAST(ast);
    
    return 0;
}
```

Link against `libcalc` from CMake.
