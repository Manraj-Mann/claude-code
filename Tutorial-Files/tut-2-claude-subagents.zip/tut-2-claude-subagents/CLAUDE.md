# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Overview

A multi-file calculator library with CLI interface. Parses and evaluates mathematical expressions with support for +, -, *, /, ^ (power), and parentheses.

**See also:**
- [`ARCHITECTURE.md`](ARCHITECTURE.md) — Data flow, module relationships, design decisions
- [`BUILDING.md`](BUILDING.md) — Build commands, CMake setup, running tests
- [`CONVENTIONS.md`](CONVENTIONS.md) — Code style, naming, error handling patterns
- [`GOTCHAS.md`](GOTCHAS.md) — Non-obvious behavior, precedence rules, memory management

## Quick Start

Build:
```bash
mkdir -p build && cd build && cmake .. && cmake --build .
```

Run:
```bash
./calc-cli
```

Test:
```bash
ctest
```

## Project Structure

```
src/            — Core library (Parser, Calculator, CLI)
tests/          — Google Test unit tests
main.cpp        — Entry point
CMakeLists.txt  — Build configuration
```

## Common Tasks

- **Add a new operator** → See [`GOTCHAS.md#add-operator`](GOTCHAS.md)
- **Debug an AST** → See [`GOTCHAS.md#debug-ast`](GOTCHAS.md)
- **Use the library** → See [`ARCHITECTURE.md#deployment`](ARCHITECTURE.md)
