#include "src/cli.h"

int main() {
    calc::CLI cli;
    cli.run();
    return 0;
}
