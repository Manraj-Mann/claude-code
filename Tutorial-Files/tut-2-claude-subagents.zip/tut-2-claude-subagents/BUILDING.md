# BUILDING.md

## Prerequisites

- CMake 3.15+
- C++17 compiler (g++, clang, MSVC)
- Google Test (for tests)

**Install dependencies:**

**Ubuntu/Debian:**
```bash
sudo apt-get install cmake g++ libgtest-dev
```

**macOS:**
```bash
brew install cmake googletest
```

## Build Steps

**1. Create build directory:**
```bash
mkdir -p build && cd build
```

**2. Configure with CMake:**
```bash
cmake ..
```

**3. Build:**
```bash
cmake --build .
```

**Result:** Executables in `build/`:
- `calc-cli` — The calculator REPL
- `calculator_tests` — Unit tests

## One-liner

```bash
mkdir -p build && cd build && cmake .. && cmake --build . && ./calc-cli
```

## Build Variants

**Debug build (with debug symbols and verbose output):**
```bash
cmake -B build -DCMAKE_BUILD_TYPE=Debug
cmake --build build --verbose
```

**Release build (optimized):**
```bash
cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build
```

## Running

**Run the CLI:**
```bash
./calc-cli
```

**Run all tests:**
```bash
ctest
```

**Run tests with output:**
```bash
ctest --output-on-failure
```

**Run a specific test:**
```bash
./calculator_tests --gtest_filter=CalculatorTest.Addition
```

**List all tests:**
```bash
./calculator_tests --gtest_list_tests
```

## Troubleshooting

**CMake not found:**
- Install CMake: `apt install cmake` (Linux) or `brew install cmake` (macOS)

**Google Test not found:**
- Install: `apt install libgtest-dev` or `brew install googletest`
- Or update CMakeLists.txt to fetch from source

**Compiler error about C++17:**
- Check your compiler version: `g++ --version`
- Update your system or use a newer compiler
