#pragma once

#include "calculator.h"
#include "parser.h"

namespace calc {

class CLI {
public:
    void run();

private:
    Calculator calculator;
    Parser parser;
};

}
