#pragma once

#include <string>

namespace calc {

struct ASTNode {
    char op;
    double value;
    ASTNode* left;
    ASTNode* right;

    ASTNode() : op('\0'), value(0), left(nullptr), right(nullptr) {}
};

class Calculator {
public:
    double evaluate(ASTNode* node);
    void deleteAST(ASTNode* node);

private:
    double applyOp(double left, double right, char op);
};

}
