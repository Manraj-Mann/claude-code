#include "calculator.h"
#include <stdexcept>
#include <cmath>

namespace calc {

double Calculator::evaluate(ASTNode* node) {
    if (!node) {
        throw std::invalid_argument("Null node in evaluation");
    }

    if (node->op == '\0') {
        return node->value;
    }

    double left = evaluate(node->left);
    double right = evaluate(node->right);

    return applyOp(left, right, node->op);
}

double Calculator::applyOp(double left, double right, char op) {
    switch (op) {
        case '+':
            return left + right;
        case '-':
            return left - right;
        case '*':
            return left * right;
        case '/':
            if (right == 0) {
                throw std::invalid_argument("Division by zero");
            }
            return left / right;
        case '^':
            return std::pow(left, right);
        default:
            throw std::invalid_argument("Unknown operator");
    }
}

void Calculator::deleteAST(ASTNode* node) {
    if (!node) return;
    deleteAST(node->left);
    deleteAST(node->right);
    delete node;
}

}
