#pragma once

#include "calculator.h"
#include <string>
#include <vector>

namespace calc {

struct Token {
    enum Type { NUMBER, PLUS, MINUS, MULT, DIV, POW, LPAREN, RPAREN, END };

    Type type;
    double value;

    Token(Type t = END, double v = 0) : type(t), value(v) {}
};

class Parser {
public:
    ASTNode* parse(const std::string& expression);

private:
    std::vector<Token> tokens;
    int current;

    std::vector<Token> tokenize(const std::string& expression);
    ASTNode* parseExpression();
    ASTNode* parseTerm();
    ASTNode* parseFactor();
    Token peek();
    Token consume();
    bool match(Token::Type type);
};

}
