#include "parser.h"
#include <cctype>
#include <sstream>
#include <stdexcept>

namespace calc {

ASTNode* Parser::parse(const std::string& expression) {
    tokens = tokenize(expression);
    current = 0;
    return parseExpression();
}

std::vector<Token> Parser::tokenize(const std::string& expression) {
    std::vector<Token> result;
    size_t i = 0;

    while (i < expression.size()) {
        if (std::isspace(expression[i])) {
            i++;
            continue;
        }

        if (std::isdigit(expression[i]) || expression[i] == '.') {
            size_t start = i;
            while (i < expression.size() && (std::isdigit(expression[i]) || expression[i] == '.')) {
                i++;
            }
            double value = std::stod(expression.substr(start, i - start));
            result.push_back(Token(Token::NUMBER, value));
        } else if (expression[i] == '+') {
            result.push_back(Token(Token::PLUS));
            i++;
        } else if (expression[i] == '-') {
            result.push_back(Token(Token::MINUS));
            i++;
        } else if (expression[i] == '*') {
            result.push_back(Token(Token::MULT));
            i++;
        } else if (expression[i] == '/') {
            result.push_back(Token(Token::DIV));
            i++;
        } else if (expression[i] == '^') {
            result.push_back(Token(Token::POW));
            i++;
        } else if (expression[i] == '(') {
            result.push_back(Token(Token::LPAREN));
            i++;
        } else if (expression[i] == ')') {
            result.push_back(Token(Token::RPAREN));
            i++;
        } else {
            throw std::invalid_argument(std::string("Unknown character: ") + expression[i]);
        }
    }

    result.push_back(Token(Token::END));
    return result;
}

ASTNode* Parser::parseExpression() {
    ASTNode* left = parseTerm();

    while (peek().type == Token::PLUS || peek().type == Token::MINUS) {
        Token op = consume();
        ASTNode* right = parseTerm();

        ASTNode* node = new ASTNode();
        node->op = (op.type == Token::PLUS) ? '+' : '-';
        node->left = left;
        node->right = right;
        left = node;
    }

    return left;
}

ASTNode* Parser::parseTerm() {
    ASTNode* left = parseFactor();

    while (peek().type == Token::MULT || peek().type == Token::DIV) {
        Token op = consume();
        ASTNode* right = parseFactor();

        ASTNode* node = new ASTNode();
        node->op = (op.type == Token::MULT) ? '*' : '/';
        node->left = left;
        node->right = right;
        left = node;
    }

    return left;
}

ASTNode* Parser::parseFactor() {
    if (peek().type == Token::POW) {
        consume();
        ASTNode* right = parseFactor();

        ASTNode* node = new ASTNode();
        node->op = '^';
        node->left = parseFactor();
        node->right = right;
        return node;
    }

    if (peek().type == Token::LPAREN) {
        consume();
        ASTNode* expr = parseExpression();
        if (peek().type != Token::RPAREN) {
            throw std::invalid_argument("Expected ')'");
        }
        consume();
        return expr;
    }

    if (peek().type == Token::NUMBER) {
        Token num = consume();
        ASTNode* node = new ASTNode();
        node->value = num.value;
        return node;
    }

    throw std::invalid_argument("Unexpected token in expression");
}

Token Parser::peek() {
    if (current < tokens.size()) {
        return tokens[current];
    }
    return Token(Token::END);
}

Token Parser::consume() {
    Token token = peek();
    current++;
    return token;
}

bool Parser::match(Token::Type type) {
    if (peek().type == type) {
        consume();
        return true;
    }
    return false;
}

}
