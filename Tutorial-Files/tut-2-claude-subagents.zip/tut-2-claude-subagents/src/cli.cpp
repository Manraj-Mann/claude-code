#include "cli.h"
#include <iostream>
#include <string>

namespace calc {

void CLI::run() {
    std::cout << "Welcome to Calculator CLI!\n";
    std::cout << "Supported operators: + - * / ^ (power)\n";
    std::cout << "Type 'exit' to quit.\n\n";

    std::string input;
    while (true) {
        std::cout << "> ";
        std::getline(std::cin, input);

        if (input == "exit") {
            std::cout << "Goodbye!" << std::endl;
            break;
        }

        if (input.empty()) {
            continue;
        }

        try {
            ASTNode* ast = parser.parse(input);
            double result = calculator.evaluate(ast);
            std::cout << "= " << result << std::endl;
            calculator.deleteAST(ast);
        } catch (const std::exception& e) {
            std::cout << "Error: " << e.what() << std::endl;
        }
    }
}

}
