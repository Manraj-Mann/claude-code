# CONVENTIONS.md

## Naming

- **Classes:** `PascalCase` (e.g., `Calculator`, `Parser`, `CLI`)
- **Functions:** `camelCase` (e.g., `parseExpression()`, `applyOp()`)
- **Constants:** `UPPER_SNAKE_CASE` (e.g., `MAX_DEPTH`)
- **Member variables:** `camelCase` with no prefix (e.g., `current`, `tokens`)
- **Enums:** `PascalCase` for type, `UPPER_SNAKE_CASE` for values (e.g., `Token::PLUS`)

## Headers

Use `#pragma once` for include guards (simpler than `#ifndef` guards):

```cpp
#pragma once

#include <string>

namespace calc { ... }
```

## Namespaces

All public code lives in `calc::` namespace to avoid naming collisions.

## Error Handling

- **Parser and Calculator:** Throw `std::invalid_argument` with descriptive messages
  ```cpp
  throw std::invalid_argument("Division by zero");
  ```

- **CLI:** Catches `std::exception` and displays to user
  ```cpp
  try {
      // parse and evaluate
  } catch (const std::exception& e) {
      std::cout << "Error: " << e.what() << std::endl;
  }
  ```

## Memory Management

- **ASTNode allocation:** Parser uses `new` to allocate nodes
- **Cleanup:** Caller must call `Calculator::deleteAST()` after evaluation
  ```cpp
  ASTNode* ast = parser.parse("2 + 3");
  double result = calc.evaluate(ast);
  calc.deleteAST(ast);  // Important: free memory
  ```

- **Future improvement:** Use `std::unique_ptr<ASTNode>` for automatic cleanup

## Code Style

- **Indentation:** 4 spaces (no tabs)
- **Braces:** Opening brace on same line (K&R style)
  ```cpp
  if (condition) {
      // code
  } else {
      // code
  }
  ```

- **Spaces:** Around operators, after control flow keywords
  ```cpp
  int x = 5 + 3;  // good
  if (x > 0) {    // good
  ```

## Comments

- Use sparingly; code should be self-explanatory
- Document the *why*, not the *what*
  ```cpp
  // Good: explains non-obvious behavior
  // Power is right-associative: 2^3^2 = 2^(3^2), not (2^3)^2
  
  // Bad: just states what the code does
  // Recursively call parseFactor
  return parseFactor();
  ```

## Testing

- Test file names: `{module}_test.cpp` (e.g., `calculator_test.cpp`)
- Test class names: `{Module}Test` (e.g., `CalculatorTest`)
- Test method names: `Test{Feature}` (e.g., `TEST_F(CalculatorTest, Addition)`)
- Use descriptive test names that explain what is being tested

## Includes

- Group includes in order: standard library, then project headers
  ```cpp
  #include <iostream>
  #include <string>
  
  #include "calculator.h"
  #include "parser.h"
  ```
