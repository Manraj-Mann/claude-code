#include <gtest/gtest.h>
#include "src/parser.h"
#include "src/calculator.h"

using namespace calc;

class ParserTest : public ::testing::Test {
protected:
    Parser parser;
    Calculator calc;

    double parseAndEval(const std::string& expression) {
        ASTNode* ast = parser.parse(expression);
        double result = calc.evaluate(ast);
        calc.deleteAST(ast);
        return result;
    }
};

TEST_F(ParserTest, SimpleNumber) {
    double result = parseAndEval("42");
    EXPECT_EQ(result, 42);
}

TEST_F(ParserTest, SimpleAddition) {
    double result = parseAndEval("5 + 3");
    EXPECT_EQ(result, 8);
}

TEST_F(ParserTest, SimpleSubtraction) {
    double result = parseAndEval("10 - 4");
    EXPECT_EQ(result, 6);
}

TEST_F(ParserTest, SimpleMultiplication) {
    double result = parseAndEval("6 * 7");
    EXPECT_EQ(result, 42);
}

TEST_F(ParserTest, SimpleDivision) {
    double result = parseAndEval("20 / 4");
    EXPECT_EQ(result, 5);
}

TEST_F(ParserTest, OperatorPrecedence) {
    double result = parseAndEval("2 + 3 * 4");
    EXPECT_EQ(result, 14);  // 3 * 4 = 12, then 2 + 12 = 14
}

TEST_F(ParserTest, Parentheses) {
    double result = parseAndEval("(2 + 3) * 4");
    EXPECT_EQ(result, 20);  // 2 + 3 = 5, then 5 * 4 = 20
}

TEST_F(ParserTest, Power) {
    double result = parseAndEval("2 ^ 3");
    EXPECT_EQ(result, 8);
}

TEST_F(ParserTest, Complex) {
    double result = parseAndEval("10 + 2 * 3 - 4");
    EXPECT_EQ(result, 12);  // 2 * 3 = 6, then 10 + 6 - 4 = 12
}

TEST_F(ParserTest, InvalidExpression) {
    EXPECT_THROW(parseAndEval("5 +"), std::invalid_argument);
}

TEST_F(ParserTest, UnmatchedParentheses) {
    EXPECT_THROW(parseAndEval("(5 + 3"), std::invalid_argument);
}
