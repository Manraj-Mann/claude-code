#include <gtest/gtest.h>
#include "src/calculator.h"

using namespace calc;

class CalculatorTest : public ::testing::Test {
protected:
    Calculator calc;

    ASTNode* createNumber(double value) {
        ASTNode* node = new ASTNode();
        node->value = value;
        node->op = '\0';
        return node;
    }

    ASTNode* createBinaryOp(char op, ASTNode* left, ASTNode* right) {
        ASTNode* node = new ASTNode();
        node->op = op;
        node->left = left;
        node->right = right;
        return node;
    }

    void TearDown() override {
        // Cleanup happens in individual tests
    }
};

TEST_F(CalculatorTest, Addition) {
    ASTNode* ast = createBinaryOp('+', createNumber(5), createNumber(3));
    double result = calc.evaluate(ast);
    EXPECT_EQ(result, 8);
    calc.deleteAST(ast);
}

TEST_F(CalculatorTest, Subtraction) {
    ASTNode* ast = createBinaryOp('-', createNumber(10), createNumber(4));
    double result = calc.evaluate(ast);
    EXPECT_EQ(result, 6);
    calc.deleteAST(ast);
}

TEST_F(CalculatorTest, Multiplication) {
    ASTNode* ast = createBinaryOp('*', createNumber(6), createNumber(7));
    double result = calc.evaluate(ast);
    EXPECT_EQ(result, 42);
    calc.deleteAST(ast);
}

TEST_F(CalculatorTest, Division) {
    ASTNode* ast = createBinaryOp('/', createNumber(20), createNumber(4));
    double result = calc.evaluate(ast);
    EXPECT_EQ(result, 5);
    calc.deleteAST(ast);
}

TEST_F(CalculatorTest, Power) {
    ASTNode* ast = createBinaryOp('^', createNumber(2), createNumber(3));
    double result = calc.evaluate(ast);
    EXPECT_EQ(result, 8);
    calc.deleteAST(ast);
}

TEST_F(CalculatorTest, DivisionByZero) {
    ASTNode* ast = createBinaryOp('/', createNumber(10), createNumber(0));
    EXPECT_THROW(calc.evaluate(ast), std::invalid_argument);
    calc.deleteAST(ast);
}
